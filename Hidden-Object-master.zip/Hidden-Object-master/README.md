# Hidden-Object
 Simple Hidden Object game

## Complete tutorial

<a href="http://www.youtube.com/watch?feature=player_embedded&v=ik9xKSNb9wU
" target="_blank"><img src="http://img.youtube.com/vi/ik9xKSNb9wU/0.jpg" 
alt="IMAGE ALT TEXT HERE" width="240" height="180" border="10" /></a>

## GamePlay
![HiddenObject](http://i.giphy.com/JPlbJxyXCcUWLRNMso.gif)

<div align="left">

### Show some ❤️ and Support!

<a href="https://www.patreon.com/bePatron?u=2787703">
  <img src="https://user-images.githubusercontent.com/39331790/55590317-6c603c80-572a-11e9-8f26-c5976ecf685b.png" width="200" height="47"/>
</a>

<a href="https://www.buymeacoffee.com/Madfireon">
  <img src="https://www.the3rdsequence.com/texturedb/images/donate/buymeacoffee.svg" width="200" height="47"/>
</a>

</div>
